int i;
float j;
double k;

