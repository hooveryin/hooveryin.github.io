#include <stdio.h>

#define HI 2+3

int main(void)
{
	printf("%d\n", HI*HI);
	return 0;
}

