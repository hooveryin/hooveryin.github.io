# 1 "preprocess.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "preprocess.c"
# 1 "preprocess.h" 1
int i;
float j;
double k;
# 2 "preprocess.c" 2

int main(void)
{

 int hi = 0;
 return 0;
}
