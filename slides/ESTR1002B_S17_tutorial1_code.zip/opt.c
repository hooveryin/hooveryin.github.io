#include <stdio.h>

int main(void)
{
	int a = 2;
	a = a + 2;
	a = a + 2;
	a = a + 2;
	a = a + 2;
	printf("%d\n", a);
	return 0;
}

