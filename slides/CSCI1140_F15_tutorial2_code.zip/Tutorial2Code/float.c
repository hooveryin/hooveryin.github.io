#include <stdio.h>

#define NUM .77777777777777777777

int main(void)
{
	float f = NUM;
	double d = NUM;
	printf("      12345678901234567890\n");
	printf("f = %.60f\n"
		   "d = %.60f\n", f, d);
	return 0;
}

