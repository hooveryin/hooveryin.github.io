#include <stdio.h>

int main(void)
{
	int a[] = {1,2,3,4,5,6,7};
	int i;
	for(i = 0; i < sizeof(a)/sizeof(int); i++)
		printf("%d\n", a[i]);
	return 0;
}

