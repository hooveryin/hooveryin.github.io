#include <stdio.h>

main()
{
	int i = 0;
start:
	if(i >= 10)
		goto end;
	printf("%d\n", i);
	i++;
	goto start;
end:;
}

