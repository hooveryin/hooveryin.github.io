int main(void)
{
	float f = .1;
	for(; f != .1f; );
	return 0;
}

