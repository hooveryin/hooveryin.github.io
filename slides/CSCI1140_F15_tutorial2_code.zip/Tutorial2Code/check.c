#include <stdio.h>

foo()
{
	printf("foo\n");
}

main()
{
	int a = foo(1);
}

