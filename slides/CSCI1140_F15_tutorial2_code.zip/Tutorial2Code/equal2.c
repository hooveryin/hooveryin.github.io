#include <stdio.h>

int main(void)
{
	int a = 10;
	if(a == 1)
		puts("A");
	else
		puts("B");
	printf("%d\n", a);
	return 0;
}

