# 1 "first.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "first.c"
# 1 "first.h" 1
int i;
float j;
double k;
# 2 "first.c" 2

int main(void)
{

 int hi = 0;
 return 0;
}
