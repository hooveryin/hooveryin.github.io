#include <stdio.h>

#define f(x) x*x

int main(void)
{
	int a = f(5);
	int b = f(2+3);
	printf("%d, %d\n", a, b);
	return 0;
}

