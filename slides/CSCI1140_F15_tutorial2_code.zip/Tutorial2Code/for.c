#include <stdio.h>

int main(void)
{
	int i = -1;
	for(i = 0; i < 10; i++)
		printf("%d\n", i);
	puts("Loop ended");
	printf("%d\n", i);
	return 0;
}

