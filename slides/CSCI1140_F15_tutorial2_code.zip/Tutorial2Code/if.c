#include <stdio.h>

int main(void)
{
	int a;
	if(a > 0)
		puts(":)");
	else
		puts(":(");
	return 0;
}

