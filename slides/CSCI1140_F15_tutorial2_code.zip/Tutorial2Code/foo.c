#include <stdio.h>

float foo(int a)
{
	printf("%d\n", a);
	return 3.14159;
}

