#include <stdio.h>

main()
{
	int c = 6 //*comment*/ 3
	;;;;;;;;;;
	printf("%d\n", c);
}

