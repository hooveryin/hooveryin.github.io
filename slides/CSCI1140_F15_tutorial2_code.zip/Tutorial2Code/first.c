#include "first.h"

int main(void)
{
	//Hello :D
	int hi = 0;
	return 0;
}

