#include <stdio.h>

//extern float foo(int);

int main(void)
{
	float b = foo(2.71828);
	printf("%f\n", b);
	return 0;
}

