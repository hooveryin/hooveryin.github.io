#include <stdio.h>

int main(void)
{
	int i;
	double d = 0;
	for(i = 0; i < 10; i++)
		d += .1;
	printf("%d\n", d == 1.);
	return 0;
}

