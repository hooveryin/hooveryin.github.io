#include <stdio.h>
#include <string.h>

int main(void)
{
	char str[8];
	memset(str, 'A', 7);
	str[7] = '\0';
	puts(str);
	return 0;
}

