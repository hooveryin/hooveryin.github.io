#include <stdio.h>

void *foo(int a[][2])
{
	int i, j;
	for(i = 0; i < 3; i++)
		for(j = 0; j < 2; j++)
			printf("value of a[%d][%d] = %d\n", i, j, a[i][j]);
}

int main(void)
{
	int i, j;
	int a[3][2];// = {{0,1},{2,3},{4,5}};
	for(i = 0; i < 3; i++)
		for(j = 0; j < 2; j++)
			a[i][j] = i*2+j;
	foo(a);
	return 0;
}

