#include <stdio.h>

int main(void)
{
	int i, j;
	int a[3][2];
	printf("size of int = %u\n", sizeof(int));
	for(i = 0; i < 3; i++)
		printf("size of a[%d] = %u\n", i, sizeof(a[i]));
	printf("size of a = %u\n", sizeof(a));
	for(i = 0; i < 3; i++)
		for(j = 0; j < 2; j++)
			printf("address of a[%d][%d] = %p\n", i, j, &a[i][j]);
	return 0;
}

