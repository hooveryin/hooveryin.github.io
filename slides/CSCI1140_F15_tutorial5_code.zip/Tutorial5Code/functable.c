#include <stdio.h>

int add(int a, int b)
{
	return a+b;
}

int sub(int a, int b)
{
	return a-b;
}

int main(void)
{
	int (*p[2])(int, int) = {add, sub};
	printf("%d, %d\n", p[0](1,2), p[1](1,2));
	return 0;
}

