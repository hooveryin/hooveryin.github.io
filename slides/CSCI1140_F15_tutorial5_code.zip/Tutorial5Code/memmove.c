#include <stdio.h>
#include <string.h>

int main(void)
{
	char *str = "Hello";
	char a[6], b[6];
	strcpy(a, str);
	strcpy(b, str);
	memcpy(a+1, a, 3);
	memmove(b+1, b, 3);
	puts(a);
	puts(b);
	return 0;
}

