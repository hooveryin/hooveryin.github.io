#include <stdio.h>

int main(void)
{
	int a[5];
	printf("Value of a      = %p\n", a);
	printf("Address of a[0] = %p\n", &a[0]);
	return 0;
}

