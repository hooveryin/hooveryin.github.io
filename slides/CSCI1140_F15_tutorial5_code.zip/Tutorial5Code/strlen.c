#include <stdio.h>
#include <string.h>

int main(void)
{
	char *a = "Hello"; //string literal
	printf("%u\n", strlen(a));
	printf("%u\n", strnlen(a, 3));
	return 0;
}

