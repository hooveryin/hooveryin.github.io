#include <stdio.h>

int main(void)
{
	int i;
	int a[5] = {0,1,2,3,4};
	int *b = a+2;
	for(i = -2; i <= 2; i++)
		printf("Value of b[%d] = %d\n", i, b[i]);
	return 0;
}

