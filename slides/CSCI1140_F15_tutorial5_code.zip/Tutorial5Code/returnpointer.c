#include <stdio.h>

int *foo(void)
{
	int a = 10;
	return &a;
}

int main(void)
{
	int *a = foo();
	printf("%d\n", *a);
	printf("%d\n", *a);
	return 0;
}

