#include <stdio.h>

int main(void)
{
	const int a = 10;
	int *b = (int*) &a;
	*b = 20;
	printf("%d\n", a);
	return 0;
}

