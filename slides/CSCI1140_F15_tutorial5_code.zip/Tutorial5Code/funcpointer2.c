#include <stdio.h>

int add(int a, int b)
{
	return a+b;
}

int main(void)
{
	void *p = (void*) add;
	printf("%d\n", ((int (*)(int, int))p)(1,2));
	return 0;
}

