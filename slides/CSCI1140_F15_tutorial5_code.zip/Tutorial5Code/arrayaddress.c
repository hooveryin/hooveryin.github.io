#include <stdio.h>

int main(void)
{
	int a[4];
	printf("%p, %p\n", a, &a);
	printf("%p, %p\n", a+1, &a+1);
	return 0;
}

