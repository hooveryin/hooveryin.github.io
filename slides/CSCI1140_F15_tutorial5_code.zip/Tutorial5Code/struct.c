#include <stdio.h>
#include <stdlib.h>

struct foo {
	int x;
	int a[]; // or   int a[0];
} *bar;

int main(void)
{
	int i;
	bar = (struct foo*) malloc(sizeof(struct foo)+5*sizeof(int));
	for(i = 0; i < 5; i++)
		bar->a[i] = i;
	for(i = 0; i < 5; i++)
		printf("%d\n", bar->a[i]);
	return 0;
}

