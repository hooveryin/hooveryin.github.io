#include <stdio.h>

int main(void)
{
	int i;
	int a[3] = {0,1,2};
	for(i = 0; i < 3; i++)
		printf("a[i] = %d\n", a[i]);
	for(i = 0; i < 3; i++)
		printf("i[a] = %d\n", i[a]);
	return 0;
}

