#include <stdio.h>

int main(void)
{
	int i, j;
	int a[3][2] = {{0,1},{2,3},{4,5}};
	int *b = (int*) a;
	for(i = 0; i < 3; i++)
		for(j = 0; j < 2; j++)
			printf("Value of *(b+%d*2+%d) = %d\n", i, j, *(b+i*2+j));
	return 0;
}

