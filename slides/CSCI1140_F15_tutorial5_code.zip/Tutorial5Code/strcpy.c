#include <stdio.h>
#include <string.h>

int main(void)
{
	char b[16];
	strcpy(b, "hello");
	puts(b);
	b[0] = 'H';
	puts(b);
	strcat(b, " World!");
	puts(b);
	return 0;
}

