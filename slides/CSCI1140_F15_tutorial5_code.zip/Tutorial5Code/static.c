#include <stdio.h>

void foo(void)
{
	static int count;
	printf("Called %d times\n", ++count);
}

int main(void)
{
	int i;
	for(i = 0; i < 5; i++)
		foo();
	return 0;
}

