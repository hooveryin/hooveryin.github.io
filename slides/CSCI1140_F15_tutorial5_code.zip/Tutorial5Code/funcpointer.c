#include <stdio.h>

int add(int a, int b)
{
	return a+b;
}

int main(void)
{
	int (*p)(int, int) = add;
	printf("%d\n", p(1,2));
	return 0;
}

