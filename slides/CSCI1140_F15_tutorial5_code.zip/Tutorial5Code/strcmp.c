#include <stdio.h>
#include <string.h>

int main(void)
{
	printf("%d\n", strcmp("Hello", "hello"));
	printf("%d\n", strcmp("world", "wor"));
	return 0;
}
