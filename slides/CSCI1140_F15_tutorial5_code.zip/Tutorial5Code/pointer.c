#include <stdio.h>

int main(void)
{
	int a;
	int *foo = &a;
	char *bar2 = (char*) &a; //may have warnings
	void *haha = &a;
	printf("Address of a = %p\n", &a);
	printf("foo + 1 = %p\n", foo+1);
	printf("bar2 + 1 = %p\n", bar2+1);
	printf("haha + 1 = %p\n", haha+1);
	return 0;
}

