#include <stdio.h>

int main(void)
{
	int i;
	int a[5];
	printf("size of int = %u\n", sizeof(int));
	printf("size of a = %u\n", sizeof(a));
	for(i = 0; i < 5; i++)
		printf("address of a[%d] = %p\n", i, &a[i]);
	return 0;
}

